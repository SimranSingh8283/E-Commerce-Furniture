<?php
function child_enqueue_styles()
{
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');

    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', ['parent-style']);
}
add_action('wp_enqueue_scripts', 'child_enqueue_styles');




add_filter('query_vars', function ($vars) {
    $vars[] = 'collection';
    return $vars;
});

add_filter('woocommerce_add_to_cart_fragments', function($fragments) {
    ob_start();
    $count = WC()->cart->get_cart_contents_count();
    $tooltip_text = $count === 0 ? 'Your cart is empty' : ($count === 1 ? '1 item in your cart' : "$count items in your cart");
    ?>
    <div class="cart-badge-wrapper">
        <div class="Badge-root" data-value="<?php echo $count; ?>">
            <a data-tooltip="<?php echo esc_attr($tooltip_text); ?>" href="<?php echo wc_get_cart_url(); ?>"
               class="Button-root Button-icon Button-shop cart-button">
                <img src="<?= get_template_directory_uri(); ?>/assets/media/shopping-cart.svg" alt="">
            </a>
        </div>
    </div>
    <?php
    $fragments['.cart-badge-wrapper'] = ob_get_clean();
    return $fragments;
});


// add_action('wp_ajax_load_product_collection', 'load_product_collection');
// add_action('wp_ajax_nopriv_load_product_collection', 'load_product_collection');

// function load_product_collection() {
//     $collection = sanitize_text_field($_POST['collection'] ?? 'all');

//     ob_start();
//     get_template_part(
//         'template-parts/products/collection',
//         null,
//         array('collection' => $collection)
//     );
//     wp_send_json_success(ob_get_clean());
// }


add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {

    ob_start();

    $count = WC()->cart->get_cart_contents_count();
    $tooltip = $count === 0
        ? 'Your cart is empty'
        : ($count === 1 ? '1 item in your cart' : "$count items in your cart");
    ?>

    <div class="header-cart-badge">
        <div class="Badge-root" data-value="<?php echo esc_attr($count); ?>">
            <a href="<?php echo esc_url(wc_get_cart_url()); ?>"
               class="Button-root Button-icon Button-shop cart-button"
               data-tooltip="<?php echo esc_attr($tooltip); ?>">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/media/shopping-cart.svg" alt="">
            </a>
        </div>
    </div>

    <?php
    $fragments['.header-cart-badge'] = ob_get_clean();

    return $fragments;
});


add_action('wp_enqueue_scripts', function() {
    if (function_exists('is_woocommerce')) {
        wp_enqueue_script('wc-cart-fragments');
    }
});


function my_force_product_cat_template($template) {
    if (is_product_category()) {
        $new_template = locate_template(['woocommerce/taxonomy-product_cat.php']);
        if ($new_template) {
            return $new_template;
        }
    }
    return $template;
}
add_filter('template_include', 'my_force_product_cat_template', 99);


function furniture_cart_css_override()
{
    if (is_cart() || is_checkout()) {
        wp_enqueue_style(
            'cart',
            get_template_directory_uri() . '/assets/css/cart.css',
            [],
            time()
        );

        wp_enqueue_script(
            'cart',
            get_template_directory_uri() . '/assets/js/cart.js',
            array('jquery'),
            time(),
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'furniture_cart_css_override', 100);


// function get_wc_login_error_for_field( $field ) {
//     $errors = wc_get_notices( 'error' );

//     if ( empty( $errors ) ) {
//         return '';
//     }

//     foreach ( $errors as $error ) {
//         $message = wp_strip_all_tags( $error['notice'] );

//         // Remove leading "Error:" (case-insensitive)
//         $message = preg_replace( '/^error:\s*/i', '', $message );

//         if ( $field === 'username' && (
//             stripos( $message, 'username' ) !== false ||
//             stripos( $message, 'email' ) !== false
//         )) {
//             return $message;
//         }

//         if ( $field === 'password' && stripos( $message, 'password' ) !== false ) {
//             return $message;
//         }
//     }

//     return '';
// }


add_action('template_redirect', function () {
    if (is_account_page() && !isset($_GET['action'])) {
        wp_safe_redirect(add_query_arg('action', 'login', get_permalink(wc_get_page_id('myaccount'))));
        exit;
    }
});

add_filter('woocommerce_registration_errors', function ($errors, $username, $email) {

    if (empty($_POST['agree_terms'])) {
        $errors->add(
            'agree_terms_error',
            __('You must agree to the Terms & Conditions and Privacy Policy.', 'woocommerce')
        );
    }

    return $errors;

}, 10, 3);


add_action('woocommerce_created_customer', function ($customer_id) {

    if (!empty($_POST['agree_terms'])) {
        update_user_meta($customer_id, '_agreed_terms', 'yes');
        update_user_meta($customer_id, '_agreed_terms_date', current_time('mysql'));
    }

});


add_filter('woocommerce_form_field', 'custom_checkout_form_field', 10, 4);
function custom_checkout_form_field($field, $key, $args, $value)
{
    if (!is_checkout())
        return $field;

    $error_message = '';

    $notices = wc_get_notices('error');
    if (!empty($notices)) {
        foreach ($notices as $notice) {
            if (stripos($notice['notice'], $key) !== false) {
                $error_message = $notice['notice'];
                break;
            }
        }
    }

    $has_error = !empty($error_message);
    $required_attr = !empty($args['required']) ? 'required aria-required="true"' : '';
    $label = $args['label'] ?? '';
    $type = $args['type'] ?? 'text';
    $id = esc_attr($key);
    $value = esc_attr($value ?? '');
    $autocomplete = esc_attr($args['autocomplete'] ?? '');

    ob_start();
    ?>
    <div class="FormControl-group <?php echo $has_error ? 'woocommerce-invalid' : ''; ?>">

        <div class="FormControl-root <?php echo !empty($args['required']) ? 'FormControl-required' : ''; ?>">

            <?php if ($label): ?>
                <label for="<?php echo $id; ?>" class="FormControl-label">
                    <?php echo esc_html($label); ?>
                </label>
            <?php endif; ?>

            <div class="InputBase-root">
                <input type="<?php echo esc_attr($type); ?>" class="InputBase-input" name="<?php echo esc_attr($key); ?>"
                    id="<?php echo $id; ?>" value="<?php echo $value; ?>" <?php echo $required_attr; ?>
                    autocomplete="<?php echo $autocomplete; ?>" />

                <fieldset>
                    <legend>
                        <?php echo esc_html($label); ?>
                    </legend>
                </fieldset>
            </div>
        </div>

        <?php if ($has_error): ?>
            <div class="FormControl-error">
                <?php echo wp_kses_post($error_message); ?>
            </div>
        <?php endif; ?>

    </div>
    <?php

    return ob_get_clean();
}

add_action('wp_ajax_woocommerce_get_refreshed_shipping', 'get_refreshed_shipping');
add_action('wp_ajax_nopriv_woocommerce_get_refreshed_shipping', 'get_refreshed_shipping');

function get_refreshed_shipping() {

    if ( isset($_POST['shipping_method']) ) {
        WC()->session->set(
            'chosen_shipping_methods',
            wc_clean($_POST['shipping_method'])
        );
    }

    WC()->cart->calculate_shipping();
    WC()->cart->calculate_totals();

    $totals = WC()->cart->get_totals();

    wp_send_json([
        'totals'    => $totals,
    ]);
}