<?php
defined('ABSPATH') || exit;

$sortBy = $_GET['sortBy'] ?? 'latest';

$args = [
    'status' => 'publish',
    'limit' => -1,
];

switch ($sortBy) {
    case 'oldest':
        $args['orderby'] = 'date';
        $args['order'] = 'ASC';
        break;

    case 'price_asc':
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = '_price';
        $args['order'] = 'ASC';
        break;

    case 'price_desc':
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = '_price';
        $args['order'] = 'DESC';
        break;

    case 'name_asc':
        $args['orderby'] = 'name';
        $args['order'] = 'ASC';
        break;

    case 'name_desc':
        $args['orderby'] = 'name';
        $args['order'] = 'DESC';
        break;

    default: // latest
        $args['orderby'] = 'date';
        $args['order'] = 'DESC';
        break;
}

$products = wc_get_products($args);
$total_products = count($products);
?>

<div class="Block-root Block-shop">
    <div class="Container-root">

        <div class="Shop-header">
            <span class="Shop-count">
                Showing <?php echo esc_html($total_products); ?> products
            </span>

            <form method="get" id="ShopSortForm">
                <label for="sortBy">Sort By:</label>
                <select id="sortBy" name="sortBy" onchange="this.form.submit()">
                    <option value="latest" <?php selected($sortBy, 'latest'); ?>>Latest</option>
                    <option value="oldest" <?php selected($sortBy, 'oldest'); ?>>Oldest</option>
                    <option value="price_asc" <?php selected($sortBy, 'price_asc'); ?>>Price: Low to High</option>
                    <option value="price_desc" <?php selected($sortBy, 'price_desc'); ?>>Price: High to Low
                    </option>
                    <option value="name_asc" <?php selected($sortBy, 'name_asc'); ?>>Name: A to Z</option>
                    <option value="name_desc" <?php selected($sortBy, 'name_desc'); ?>>Name: Z to A</option>
                </select>

                <?php
                foreach ($_GET as $key => $value) {
                    if ($key === 'sortBy')
                        continue;
                    echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
                }
                ?>
            </form>
        </div>

        <?php if (!empty($products)): ?>
            <ul class="Flex-root Flex-wrap Products-root Products--grid">
                <?php foreach ($products as $product): ?>
                    <?php
                    if (!$product || !$product->is_visible()) {
                        continue;
                    }

                    $product_id = $product->get_id();
                    $permalink = $product->get_permalink();
                    $title = $product->get_name();
                    $image_id = $product->get_image_id();
                    $image_url = wp_get_attachment_image_url($image_id, 'medium');
                    ?>

                    <li class="Col-root Col-lg-4 Col-md-6 Product-root" data-product-id="<?php echo esc_attr($product_id); ?>">
                        <div class="Product-thumbnail">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($title); ?>">
                        </div>

                        <div class="Product-category">
                            <?php
                            $categories = wp_get_post_terms($product_id, 'product_cat');
                            if (!empty($categories) && !is_wp_error($categories)) {
                                $category_links = [];

                                foreach ($categories as $category) {
                                    $link = get_term_link($category);
                                    if (!is_wp_error($link)) {
                                        $category_links[] = '<a href="' . esc_url($link) . '" class="Product-category-link">' . esc_html($category->name) . '</a>';
                                    }
                                }

                                echo implode(', ', $category_links);
                            }
                            ?>
                        </div>

                        <div class="Product-wishlist" data-product-id="<?php echo esc_attr($product_id); ?>">

                            <div class="Product-wishlist-native" style="display:none;">
                                <?php echo do_shortcode('[woosw id="' . $product_id . '"]'); ?>
                            </div>

                            <button class="Button-root Button-icon Button-wishlist" data-tooltip="Add to Wishlist"
                                aria-label="Add to Wishlist">
                                <iconify-icon icon="mdi:heart-outline"></iconify-icon>
                            </button>
                        </div>

                        <div class="Product-overlay">
                            <a href="<?php echo esc_url($permalink); ?>" class="Product-title">
                                <span><?php echo esc_html($title); ?></span>
                            </a>

                            <div class="Product-action">
                                <?php
                                get_template_part('template-parts/products/add-to-cart', null, ['product' => $product]);
                                ?>
                            </div>

                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No products found.</p>
        <?php endif; ?>

    </div>
</div>