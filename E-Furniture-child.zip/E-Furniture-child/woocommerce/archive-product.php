<?php
defined('ABSPATH') || exit;

get_header('shop');

if (is_shop()) {
    get_template_part('template-parts/products/shop-layout');

    if (!isset($_GET['sortBy'])) {
        $shop_url = get_permalink(wc_get_page_id('shop'));

        if (!empty($_SERVER['QUERY_STRING'])) {
            $shop_url = add_query_arg($_GET, $shop_url);
        }

        $shop_url = add_query_arg('sortBy', 'latest', $shop_url);

        wp_safe_redirect($shop_url);
        exit;
    }

} else {
    get_template_part('template-parts/products/archive-layout');
}

get_footer('shop');
?>

<script>
    jQuery(function ($) {

        $('.Product-wishlist').each(function () {
            syncWishlistUI($(this));
        });

        function syncWishlistUI($wrap) {
            const $nativeBtn = $wrap.find('.woosw-btn');
            const $btn = $wrap.find('.Button-wishlist');

            if ($nativeBtn.hasClass('woosw-added')) {
                $btn
                    .addClass('is-added')
                    .attr({
                        'data-tooltip': 'View Wishlist',
                        'aria-label': 'View Wishlist'
                    })
                    .html('<iconify-icon icon="mdi:heart"></iconify-icon>');
            }
        }

        $('.Product-wishlist').on('click', '.Button-wishlist', function (e) {
            e.preventDefault();

            const $btn = $(this);
            const $wrap = $btn.closest('.Product-wishlist');
            const $nativeBtn = $wrap.find('.woosw-btn');

            $nativeBtn.trigger('click');

            if (!$btn.hasClass('is-added')) {
                $btn.addClass('Button-loading');
            }
        });

        const observer = new MutationObserver(mutations => {
            mutations.forEach(m => {
                if (
                    m.target.classList &&
                    m.target.classList.contains('woosw-btn') &&
                    m.target.classList.contains('woosw-added')
                ) {
                    const $nativeBtn = $(m.target);
                    const $wrap = $nativeBtn.closest('.Product-wishlist');
                    const $btn = $wrap.find('.Button-wishlist');

                    $btn
                        .removeClass('Button-loading')
                        .addClass('is-added')
                        .attr({
                            'data-tooltip': 'View Wishlist',
                            'aria-label': 'View Wishlist'
                        })
                        .html('<iconify-icon icon="mdi:heart"></iconify-icon>');
                }
            });
        });

        $('.woosw-btn').each(function () {
            observer.observe(this, { attributes: true, attributeFilter: ['class'] });
        });

    });
</script>