<?php
/**
 * Empty cart page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-empty.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined('ABSPATH') || exit;

if (wc_get_page_id('shop') > 0): ?>

    <div class="Block-root Block-cart BlockNote-root Block-cart--empty">
        <div class="Container-root">

            <div class="Note-content">
                <?php // do_action('woocommerce_cart_is_empty'); ?>

                <div class="Block-heading">
                    <h1 data-level="1" aria-level="1">Your cart is currently empty.</h1>
                    <p>Looks like you haven’t added anything yet.</p>
                </div>

                <div class="Action-root text-center" style="display: flex; justify-content: center;">
                    <a class="Button-root Button-icon-start Button-primary wc-backward<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"
                        data-variant="contained"
                        href="<?php echo esc_url(apply_filters('woocommerce_return_to_shop_redirect', wc_get_page_permalink('shop'))); ?>">
                        <iconify-icon icon="mdi:cart-plus"></iconify-icon>
                        <?php
                        /**
                         * Filter "Continue Shopping" text.
                         *
                         * @since 4.6.0
                         * @param string $default_text Default text.
                         */
                        echo esc_html(apply_filters('woocommerce_return_to_shop_text', __('Continue Shopping', 'woocommerce')));
                        ?>
                    </a>
                </div>
            </div>

        </div>
    </div>
<?php endif; ?>