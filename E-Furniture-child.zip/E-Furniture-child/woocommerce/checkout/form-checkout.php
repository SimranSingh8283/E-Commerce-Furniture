<?php
defined('ABSPATH') || exit;

if (!$checkout->is_registration_enabled() && $checkout->is_registration_required() && !is_user_logged_in()) {
    echo esc_html(__('You must be logged in to checkout.', 'woocommerce'));
    return;
}

$fields = $checkout->get_checkout_fields('billing');
?>

<section class="Block-root Block-checkout">
    <div class="Container-root">

        <form name="checkout" method="post" class="checkout woocommerce-checkout Step-checkout"
            action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">

            <div class="Flex-root Flex-nowrap">
                <div class="Col-root Col-lg-7">
                    <div class="Checkout-header">
                        <ul class="Checkout-status">
                            <li class="Checkout-progress">
                                <span class="Checkout-progressBar"></span>
                            </li>
                        </ul>

                        <button type="button" class="Button-root Button-primary Button-icon-end step-prev"
                            data-variant="contained" data-prev="1" style="display:none;">
                            <iconify-icon icon="tabler:arrow-left"></iconify-icon>
                            <span>Back</span>
                        </button>
                    </div>

                    <div class="Checkout-steps">
                        <?php do_action('woocommerce_checkout_before_customer_details'); ?>

                        <div class="Checkout-step" id="step-1">
                            <div class="Flex-root Flex-wrap">
                                <div class="Col-root Col-12">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_email',
                                        $fields['billing_email'],
                                        $checkout->get_value('billing_email')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-12">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_country',
                                        $fields['billing_country'],
                                        $checkout->get_value('billing_country')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-6">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_first_name',
                                        $fields['billing_first_name'],
                                        $checkout->get_value('billing_first_name')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-6">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_last_name',
                                        $fields['billing_last_name'],
                                        $checkout->get_value('billing_last_name')
                                    );
                                    ?>
                                </div>


                                <div class="Col-root Col-12">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_address_1',
                                        $fields['billing_address_1'],
                                        $checkout->get_value('billing_address_1')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-4">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_city',
                                        $fields['billing_city'],
                                        $checkout->get_value('billing_city')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-4">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_state',
                                        $fields['billing_state'],
                                        $checkout->get_value('billing_state')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-4">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_postcode',
                                        $fields['billing_postcode'],
                                        $checkout->get_value('billing_postcode')
                                    );
                                    ?>
                                </div>

                                <div class="Col-root Col-12">
                                    <?php
                                    woocommerce_form_field(
                                        'billing_phone',
                                        $fields['billing_phone'],
                                        $checkout->get_value('billing_phone')
                                    );
                                    ?>
                                </div>
                            </div>
                        </div>

                        <?php do_action('woocommerce_checkout_after_customer_details'); ?>

                        <div class="Checkout-step" id="step-2">
                            <div class="Block-heading">
                                <h3><?php esc_html_e('Shipping Method', 'woocommerce'); ?></h3>

                                <?php
                                if (WC()->cart && WC()->cart->needs_shipping()):

                                    WC()->cart->calculate_totals();
                                    WC()->cart->calculate_shipping();

                                    $packages = WC()->shipping()->get_packages();
                                    $method_counter = 0;

                                    if (!empty($packages)):
                                        ?>

                                        <div class="Checkout-shipping-methods">

                                            <?php do_action('woocommerce_review_order_before_shipping'); ?>

                                            <?php foreach ($packages as $i => $package):

                                                if (empty($package['rates'])) {
                                                    continue;
                                                }

                                                $available_methods = $package['rates'];

                                                $chosen_methods = WC()->session->get('chosen_shipping_methods');
                                                $chosen_method = is_array($chosen_methods) && isset($chosen_methods[$i])
                                                    ? $chosen_methods[$i]
                                                    : '';

                                                ?>

                                                <ul class="Shipping-methods">

                                                    <?php foreach ($available_methods as $method_id => $method):

                                                        $taxes = !empty($method->taxes) ? array_sum($method->taxes) : 0;

                                                        $shipping_map = [
                                                            'flat_rate:10' => [
                                                                'title' => 'Standard Delivery',
                                                                'desc' => 'Delivery in 5–7 business days.',
                                                            ],
                                                            'flat_rate:11' => [
                                                                'title' => 'Express Delivery',
                                                                'desc' => 'Fast delivery in 1–2 business days.',
                                                            ],
                                                            'flat_rate:12' => [
                                                                'title' => 'White Glove Delivery',
                                                                'desc' => 'Delivery, unpacking & setup in your room.',
                                                            ],
                                                        ];

                                                        $title = $method->get_label();
                                                        $desc = '';

                                                        if (isset($shipping_map[$method_id])) {
                                                            $title = $shipping_map[$method_id]['title'];
                                                            $desc = $shipping_map[$method_id]['desc'];
                                                        }

                                                        $checked = ($method_counter === 1) ? 'checked' : '';
                                                        ?>

                                                        <li class="Shipping-method">
                                                            <label class="Button-root Shipping-label" data-variant="outlined"
                                                                for="shipping_method_<?php echo esc_attr($method_counter); ?>">
                                                                <input type="radio"
                                                                    id="shipping_method_<?php echo esc_attr($method_counter); ?>"
                                                                    name="shipping_method[<?php echo esc_attr($i); ?>]" value="<?php echo esc_attr($method_id); ?>"
                                                                    <?php echo $checked ?> />

                                                                <div class="Shipping-info">
                                                                    <span class="Shipping-title">
                                                                        <?php echo esc_html($title); ?>
                                                                    </span>

                                                                    <?php if ($desc): ?>
                                                                        <small class="Shipping-desc">
                                                                            <?php echo esc_html($desc); ?>
                                                                        </small>
                                                                    <?php endif; ?>
                                                                </div>

                                                                <div class="Shipping-price">
                                                                    <?php echo wc_price($method->cost + $taxes); ?>
                                                                </div>
                                                            </label>
                                                        </li>
                                                        <?php $method_counter++; ?>

                                                    <?php endforeach; ?>

                                                </ul>

                                            <?php endforeach; ?>

                                            <?php do_action('woocommerce_review_order_after_shipping'); ?>

                                        </div>

                                        <?php
                                    endif;
                                endif;
                                ?>
                            </div>
                        </div>

                        <div class="Checkout-step" id="step-3">

                            <div class="Block-heading">
                                <h3><?php esc_html_e('Payment Method', 'woocommerce'); ?></h3>
                            </div>

                            <div id="payment" class="woocommerce-checkout-payment">
                            </div>
                        </div>
                    </div>

                    <ul class="Checkout-info">
                        <li class="Checkout-item">
                            <iconify-icon icon="tabler:info-hexagon"></iconify-icon>
                            <span>
                                1. Non-toxic exploitive environment.
                            </span>
                        </li>
                        <li class="Checkout-item">
                            <iconify-icon icon="tabler:info-hexagon"></iconify-icon>
                            <span>
                                2. This product is made with natural stone, antiqued metal, concrete, and reclaimed
                                wood. These products include unavoidable variation in color, texture, uneven grain,
                                blemishes, scratches, marks, and cracks. These features are not defects, but rather the
                                material’s natural characteristics. By ordering products from this collection, you
                                accept the characteristics unique to each item and agree that no claims will be approved
                                regarding these natural variations. </span>
                        </li>
                    </ul>

                    <button type="button" class="Button-root Button-primary Button-icon-start step-next"
                        data-variant="contained" data-next="2">
                        <span>Continue</span>
                        <iconify-icon icon="tabler:arrow-right"></iconify-icon>
                    </button>

                </div>

                <div class="Col-root Col-lg-5">
                    <?php wc_get_template('checkout/review-order.php'); ?>
                </div>

            </div>

            <?php /*
if (function_exists('woocommerce_checkout_payment')) {
echo '<div class="Checkout-payment">';

woocommerce_checkout_payment($checkout);

echo '</div>';
} */
            ?>

        </form>

    </div>
</section>

<?php do_action('woocommerce_after_checkout_form', $checkout); ?>

<script>
    jQuery(function ($) {

        function refreshShipping() {
            $('body').trigger('update_checkout');
        }

        $(document).on('change', 'input[name^="shipping_method"]', refreshShipping);
        $(document).on('change', '#billing_country, #billing_state, #billing_postcode, #billing_city', refreshShipping);

    });
    jQuery(function ($) {

    $(document.body).on('updated_checkout', function () {

        const shipping_methods = $('input[name^="shipping_method"]:checked')
            .serializeArray()
            .reduce((acc, curr) => {
                acc[curr.name.match(/\d+/)] = curr.value;
                return acc;
            }, {});

        const $shippingPrice = $('.Summary-item.shipping .shipping-total');
        const $total = $('.Summary-item .Summary-total');
        const $loading = $('.Shipping-loading');

        $loading.show();

        $.ajax({
            url: wc_checkout_params.ajax_url,
            type: 'POST',
            data: {
                action: 'woocommerce_get_refreshed_shipping',
                shipping_method: shipping_methods
            },
            success: function (res) {
                if (res?.totals?.shipping_total !== undefined) {
                    $shippingPrice.html('₹' + Number(res.totals.shipping_total).toFixed(2));
                }

                if (res?.totals?.total !== undefined) {
                    $total.html('<strong>₹' + Number(res.totals.total).toFixed(2) + '</strong>');
                }

                $loading.hide();
            },
            error: function () {
                $loading.hide();
            }
        });
    });

});



    jQuery(function ($) {
        if (!$('form.woocommerce-checkout').length) return;

        function attachCheckoutErrors() {
            $('.FormControl-error').text('');
            $('.FormControl-root').removeClass('FormControl-invalid');

            $('.woocommerce-NoticeGroup-checkout li').each(function () {
                var field_id = $(this).data('id');
                var message = $(this).text().trim();

                var $fieldWrapper = $('#' + field_id).closest('.FormControl-group');
                var $fieldRoot = $('#' + field_id).closest('.FormControl-root');
                if ($fieldWrapper.length) {
                    var $errorDiv = $fieldWrapper.find('.FormControl-error');
                    if ($errorDiv.length) {
                        $errorDiv.text(message);
                    } else {
                        $errorDiv = $('<div class="FormControl-error"></div>').text(message);
                        $fieldWrapper.append($errorDiv);
                    }

                    $fieldRoot.addClass('FormControl-invalid');
                    $fieldWrapper.find('.FormControl-root').addClass('FormControl-invalid');
                }

                // $(this).remove();
            });

            if ($('.woocommerce-NoticeGroup-checkout li').length === 0) {
                $('.woocommerce-NoticeGroup-checkout').hide();
            }
        }

        attachCheckoutErrors();

        $(document.body).on('checkout_error checkout_place_order_failed', function () {
            attachCheckoutErrors();
        });

        $(document).on('input change', '.FormControl-root input, .FormControl-root select, .FormControl-root textarea', function () {
            var $root = $(this).closest('.FormControl-root');
            var $group = $(this).closest('.FormControl-group');

            $root.removeClass('FormControl-invalid');

            $group.find('.FormControl-error').remove();
        });
    });
</script>

<script>
    jQuery(function ($) {

        const $steps = $('.Checkout-steps > .Checkout-step');
        const $status = $('.Checkout-status');

        if (!$steps.length || !$status.length) return;

        const totalSteps = $steps.length;
        const $nextBtn = $('.step-next');
        const $prevBtn = $('.step-prev');

        let currentStep = getStepFromUrl();

        /* ------------------------
           Build status dynamically
        ------------------------- */
        function buildStatus() {
            // $status.empty();

            for (let i = 1; i <= totalSteps; i++) {
                $status.append(`
                <li data-step="${i}">
                    <iconify-icon icon="tabler:check"></iconify-icon>
                </li>
            `);
            }
        }

        function updateProgress(step) {
            if (totalSteps <= 1) return;

            const percent = ((step - 1) / (totalSteps - 1)) * 100;
            $('.Checkout-progressBar').css('width', percent + '%');
        }
        /* ------------------------
           URL helpers
        ------------------------- */
        function getStepFromUrl() {
            const params = new URLSearchParams(window.location.search);
            const step = parseInt(params.get('step'), 10);
            return (!isNaN(step) && step >= 1 && step <= totalSteps) ? step : 1;
        }

        function updateUrl(step) {
            const url = new URL(window.location.href);
            url.searchParams.set('step', step);
            history.pushState({ step }, '', url);
        }

        /* ------------------------
           UI updates
        ------------------------- */
        function updateStatus(step) {
            $status.find('li')
                .removeClass('is-active is-complete')
                .removeAttr('data-tooltip');

            $status.find('li').each(function () {
                const liStep = parseInt($(this).data('step'), 10);

                if (liStep < step) {
                    $(this)
                        .addClass('is-complete')
                        .attr('data-tooltip', 'Completed');
                }
                else if (liStep === step) {
                    $(this)
                        .addClass('is-active')
                        .attr('data-tooltip', 'Current step');
                }
            });
        }


        function showStep(step) {
            currentStep = step;

            $steps.removeClass('is-active').hide();

            $('#step-' + step)
                .show(0)
                .addClass('is-active');

            updateStatus(step);
            updateProgress(step);

            step > 1 ? $prevBtn.show(100) : $prevBtn.hide(100);
            step >= totalSteps ? $nextBtn.hide(100) : $nextBtn.show(100);

            if (window.lenis) {
                window.lenis.scrollTo(0, {
                    immediate: false,
                    lerp: 0.08
                });
            }
        }

        /* ------------------------
           Init
        ------------------------- */
        buildStatus();
        showStep(currentStep);

        /* ------------------------
           Navigation
        ------------------------- */
        $nextBtn.on('click', function () {
            if (currentStep >= totalSteps) return;
            updateUrl(currentStep + 1);
            showStep(currentStep + 1);
        });

        $prevBtn.on('click', function () {
            if (currentStep <= 1) return;
            updateUrl(currentStep - 1);
            showStep(currentStep - 1);
        });

        window.addEventListener('popstate', function () {
            showStep(getStepFromUrl());
        });

    });
</script>