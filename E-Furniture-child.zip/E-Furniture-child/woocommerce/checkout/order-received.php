<?php
/**
 * "Order received" message.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/order-received.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.8.0
 *
 * @var WC_Order|false $order
 */

defined('ABSPATH') || exit;
?>

<div class="Order-success">
    <div class="Order-icon">
        <iconify-icon icon="ci:check"></iconify-icon>
    </div>

    <div class="Block-heading">
        <h1 aria-level="1" data-level="1">Your Order Is Completed!</h1>
        <p>
            <?php
            /**
             * Filter the message shown after a checkout is complete.
             *
             * @since 2.2.0
             *
             * @param string         $message The message.
             * @param WC_Order|false $order   The order created during checkout, or false if order data is not available.
             */
            $message = apply_filters(
                'woocommerce_thankyou_order_received_text',
                esc_html(__('Your order has been placed successfully. Now you can follow its progress by tracking it.', 'woocommerce')),
                $order
            );

            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo $message;
            ?>
        </p>
    </div>
</div>