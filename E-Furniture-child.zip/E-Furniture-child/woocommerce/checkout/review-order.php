<?php
/**
 * Review order
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

defined('ABSPATH') || exit;

add_filter('gettext', function ($translated, $text, $domain) {

    if (
        is_checkout() &&
        $domain === 'woocommerce' &&
        $text === 'Shipping'
    ) {
        return '';
    }

    return $translated;
}, 20, 3);
?>

<div class="WCReview-wrapper" data-scroll='lenis'>
    <div class="scroll-content">
        <div class="WCReview-list">
            <?php
            do_action('woocommerce_review_order_before_cart_contents');

            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);

                if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key)) {
                    $product_link = get_permalink($_product->get_id());
                    ?>
                    <a href="<?php echo esc_url($product_link); ?>" class="WCReview-root Button-root">
                        <div class="WCReview-thumbnail">
                            <?php
                            echo wp_kses_post($_product->get_image('thumbnail'));

                            echo apply_filters(
                                'woocommerce_checkout_cart_item_quantity',
                                '<strong class="WCReview-quantity">' . sprintf('x&nbsp;%s', $cart_item['quantity']) . '</strong>',
                                $cart_item,
                                $cart_item_key
                            );
                            ?>
                        </div>

                        <div class="WCReview-content">
                            <div class="WCReview-name">
                                <?php echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key)); ?>
                            </div>

                            <div class="WCReview-price">
                                <?php echo wc_price($_product->get_price()); ?>
                            </div>

                            <?php
                            $formatted_attributes = wc_get_formatted_cart_item_data($cart_item);
                            if (!empty($formatted_attributes)): ?>
                                <div class="WCReview-attributes">
                                    <?php echo $formatted_attributes; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </a>
                    <?php
                }
            }

            do_action('woocommerce_review_order_after_cart_contents');
            ?>
        </div>
    </div>
</div>




<div class="Cart-summary">
    <div class="Block-heading">
        <span aria-level="1" data-level="1"><?php esc_html_e('Order Summary', 'woocommerce'); ?></span>
    </div>

    <ul class="Summary-root">
        <li class="Summary-item">
            <strong>Items:</strong>
            <span><?php echo WC()->cart->get_cart_contents_count(); ?></span>
        </li>
        <li class="Summary-item">
            <strong>Subtotal</strong>
            <span><?php wc_cart_totals_subtotal_html(); ?></span>
        </li>

        <?php if (WC()->cart->needs_shipping() && WC()->cart->show_shipping()): ?>
            <li class="Summary-item shipping">
                <strong>Shipping</strong>
                <span class="woocommerce-Price-amount amount shipping-total">
                    <?php echo wc_price(WC()->cart->get_shipping_total()); ?>
                </span>
            </li>
        <?php endif; ?>


        <?php if (wc_tax_enabled() && !WC()->cart->display_prices_including_tax()): ?>
            <?php if ('itemized' === get_option('woocommerce_tax_total_display')): ?>
                <?php foreach (WC()->cart->get_tax_totals() as $code => $tax): ?>
                    <li class="Summary-item">
                        <strong><?php echo esc_html($tax->label); ?></strong>
                        <span><?php echo wp_kses_post($tax->formatted_amount); ?></span>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="Summary-item">
                    <strong>Taxes</strong>
                    <span><?php wc_cart_totals_taxes_total_html(); ?></span>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        <?php do_action('woocommerce_review_order_before_order_total'); ?>
        <li class="Summary-item">
            <strong>Total</strong>
            <span class="Summary-total"><?php wc_cart_totals_order_total_html(); ?></span>
        </li>

        <li class="Shipping-loading" style="display:none;">
            <iconify-icon icon="svg-spinners:ring-resize"></iconify-icon>
        </li>
        <?php do_action('woocommerce_review_order_after_order_total'); ?>
    </ul>
</div>