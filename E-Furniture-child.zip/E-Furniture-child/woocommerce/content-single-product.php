<?php
defined('ABSPATH') || exit;

global $product;

if (post_password_required()) {
    echo get_the_password_form();
    return;
}
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class('', $product); ?>>

    <div class="Product-container">

        <div class="Product-header">

            <!-- Product Images -->
            <div class="Product-images">
                <?php if ($product->is_on_sale()): ?>
                    <span class="onsale"><?php esc_html_e('Sale!', 'woocommerce'); ?></span>
                <?php endif; ?>

                <?php
                $attachment_ids = $product->get_gallery_image_ids();
                $main_image_id = $product->get_image_id();
                $main_image_url = wp_get_attachment_url($main_image_id);

                if ($main_image_id) {
                    echo '<a href="' . esc_url($main_image_url) . '" data-fancybox="gallery">';
                    echo wp_get_attachment_image($main_image_id, 'shop_single');
                    echo '</a>';
                }

                if ($attachment_ids) {
                    foreach ($attachment_ids as $attachment_id) {
                        $url = wp_get_attachment_url($attachment_id);
                        echo '<a href="' . esc_url($url) . '" data-fancybox="gallery">';
                        echo wp_get_attachment_image($attachment_id, 'shop_single');
                        echo '</a>';
                    }
                }
                ?>
            </div>

            <!-- Product Summary -->
            <div class="Product-summary">

                <!-- Title -->
                <h1 class="product_title entry-title"><?php echo esc_html($product->get_name()); ?></h1>

                <!-- Rating -->
                <div class="woocommerce-product-rating">
                    <?php
                    if ($product->get_average_rating()) {
                        echo wc_get_rating_html($product->get_average_rating());
                    }
                    ?>
                </div>

                <!-- Price -->
                <p class="price"><?php echo $product->get_price_html(); ?></p>

                <!-- Short Description -->
                <div class="woocommerce-product-details__short-description">
                    <?php echo apply_filters('woocommerce_short_description', $product->get_short_description()); ?>
                </div>

                <!-- Add to Cart -->
                <div class="woocommerce-add-to-cart">
                    <?php
                    if ($product->is_type('simple')) {
                        woocommerce_simple_add_to_cart();
                    } elseif ($product->is_type('variable')) {
                        woocommerce_variable_add_to_cart();
                    } else {
                        woocommerce_template_single_add_to_cart();
                    }
                    ?>
                </div>

                <div class="product-wishlist">
                    <?php echo do_shortcode('[woosw id="' . $product->get_id() . '"]'); ?>
                </div>

                <!-- Trust Badge -->
                <div class="trust-badges">
                    <p>Guaranteed Safe Checkout</p>
                    <img src="<?= site_url('/wp-content/uploads/2025/12/p-opp.png'); ?>" alt="">
                </div>

                <!-- Sharing -->
                <div class="product-sharing">
                    <?php woocommerce_template_single_sharing(); ?>
                </div>

            </div>
        </div>

        <div class="Product-footer">
            <div class="woocommerce-tabs wc-tabs-wrapper">
                <?php woocommerce_output_product_data_tabs(); ?>
            </div>

            <div class="upsells">
                <?php woocommerce_upsell_display(); ?>
            </div>

            <div class="related-products">
                <?php woocommerce_output_related_products(); ?>
            </div>
        </div>

    </div>
</div>

<section id="Block-design" class="Block-root Block-design">
    <div class="container">

        <div class="row">

        </div>

    </div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".quantity").forEach(function (qty) {
            if (qty.classList.contains("with-plus-minus")) return;
            qty.classList.add("with-plus-minus");

            let input = qty.querySelector("input.qty");
            if (!input) return;

            let minus = document.createElement("button");
            minus.className = "qty-minus";
            minus.type = "button";
            minus.textContent = "-";

            let plus = document.createElement("button");
            plus.className = "qty-plus";
            plus.type = "button";
            plus.textContent = "+";

            qty.prepend(minus);
            qty.append(plus);

            minus.addEventListener("click", function () {
                let v = parseFloat(input.value);
                if (v > 1) input.value = v - 1;
            });

            plus.addEventListener("click", function () {
                let v = parseFloat(input.value);
                input.value = v + 1;
            });
        });
    });
</script>