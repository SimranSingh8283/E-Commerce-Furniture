<?php
/**
 * Login Form with Register toggle
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-login.php.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.9.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

$post_id = wc_get_page_id('myaccount');
$attachment_id = get_post_thumbnail_id($post_id);

if ($attachment_id) {
    $banner_full = wp_get_attachment_image_src($attachment_id, 'full')[0];
    $banner_medium = wp_get_attachment_image_src($attachment_id, 'hero-medium')[0] ?? $banner_full;
    $banner_small = wp_get_attachment_image_src($attachment_id, 'hero-small')[0] ?? $banner_medium;

    $alt_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
    $title_text = get_the_title($attachment_id);
}

$show_register = isset($_GET['action']) && $_GET['action'] === 'register';
$enable_registration = 'yes' === get_option('woocommerce_enable_myaccount_registration');

do_action('woocommerce_before_customer_login_form');
?>



<style>
    .woocommerce-notices-wrapper:empty {
        display: none;
    }
    .woocommerce-notices-wrapper {
        position: fixed;
        inset: 0 0 auto 0;
        z-index: 999;
        background-color: hsl(0, 0%, 100%, 70%);
        border-top: 0.35em solid var(--clr-error);
        backdrop-filter: blur(1rem);
        box-shadow: 0 0 1rem rgba(0, 0, 0, 0.1);
    }

    .woocommerce-notices-wrapper .woocommerce-error {
        display: flex;
        gap: 1rem;
        align-items: center;
        margin: 0;
        max-width: 1320px;
        margin-inline: auto;
        background-color: transparent;
        border: 0;
    }

    .woocommerce-error::before {
        position: static;
    }
</style>

<section class="Block-root Block-static Block-login">
    <div class="Container-root">
        <div class="Flex-root Flex-nowrap Block-row">

            <div class="Col-root Col-lg-6">
                <?php
                if ($show_register) {
                    wc_get_template('myaccount/register.php');
                } else {
                    wc_get_template('myaccount/login.php');
                }
                ?>
            </div>

            <div class="Col-root Col-lg-6 Block-object">
                <div class="Object-wrapper">
                    <?php if ($attachment_id): ?>
                        <picture>
                            <source media="(max-width: 600px)" srcset="<?= esc_url($banner_small); ?>">
                            <source media="(max-width: 1024px)" srcset="<?= esc_url($banner_medium); ?>">
                            <img src="<?= esc_url($banner_full); ?>" alt="<?= esc_attr($alt_text); ?>"
                                title="<?= esc_attr($title_text); ?>">
                        </picture>
                    <?php endif; ?>

                    <div class="Object-content">
                        <div class="Block-heading">
                            <span aria-level="1" data-level="1">Crafted for the Way You Live</span>
                            <p>Behind every detail lies craftsmanship with purpose. The curve of a chair designed for
                                hours of comfort, the texture of wood that grows richer with time, the balance between
                                elegance and practicality, all come together to shape furniture that adapts to your
                                lifestyle.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php do_action('woocommerce_after_customer_login_form'); ?>