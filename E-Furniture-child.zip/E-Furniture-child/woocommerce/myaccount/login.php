<?php
if (!defined('ABSPATH'))
    exit;

$enable_registration = 'yes' === get_option('woocommerce_enable_myaccount_registration');
?>


<div class="Block-content">
    <div class="Block-heading">
        <h1 aria-level="1" data-level="1"><?php esc_html_e('Login', 'woocommerce'); ?></h1>
        <p>Welcome back to your furniture haven, where timeless design and everyday comfort come
            together to create the home you’ve always imagined.</p>
    </div>

    <form class="Form-root Form-login woocommerce-form" id="Form-login" method="post" novalidate>
        <?php do_action('woocommerce_login_form_start'); ?>

        <div class="FormControl-group">
            <div class="FormControl-root FormControl-required">
                <label for="username"
                    class="FormControl-label"><?php esc_html_e('Username or email address', 'woocommerce'); ?></label>
                <div class="InputBase-root">
                    <input type="text" class="InputBase-input" name="username" id="username" autocomplete="username"
                        value="<?php echo (!empty($_POST['username']) && is_string($_POST['username'])) ? esc_attr(wp_unslash($_POST['username'])) : ''; ?>"
                        required aria-required="true" />
                    <fieldset>
                        <legend>Username or email address *</legend>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="FormControl-group">
            <div class="FormControl-root FormControl-required">
                <label for="password" class="FormControl-label"><?php esc_html_e('Password', 'woocommerce'); ?></label>
                <div class="InputBase-root">
                    <input class="InputBase-input" type="password" name="password" id="password"
                        autocomplete="current-password" required aria-required="true" />
                    <fieldset>
                        <legend>Password *</legend>
                    </fieldset>
                </div>
            </div>
        </div>

        <?php do_action('woocommerce_login_form'); ?>

        <div class="Form-row-check">
            <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox"
                id="rememberme" value="forever" />
            <span><?php esc_html_e('Remember me', 'woocommerce'); ?></span>
        </div>

        <div class="Form-action">
            <?php wp_nonce_field('woocommerce-login', 'woocommerce-login-nonce'); ?>
            <button type="submit"
                class="Button-root Button-primary Button-icon-start woocommerce-form-login__submit<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"
                name="login" data-variant="contained" value="<?php esc_attr_e('Sign In', 'woocommerce'); ?>">
                <iconify-icon icon="line-md:login"></iconify-icon>
                <?php esc_html_e('Sign In', 'woocommerce'); ?>
            </button>

            <div class="Form-resetPassword">
                <a
                    href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php esc_html_e('Lost your password?', 'woocommerce'); ?></a>
            </div>
        </div>

        <?php do_action('woocommerce_login_form_end'); ?>
    </form>

    <div class="sign-up-bar">or</div>
    <div class="sign-up">
        Don’t have an account?
        <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>?action=register">
            Sign Up
        </a>
    </div>

</div>