<?php
if (!defined('ABSPATH'))
    exit;

$enable_registration = 'yes' === get_option('woocommerce_enable_myaccount_registration');
?>

<div class="Block-content">
    <div class="Block-heading">
        <h1 aria-level="1" data-level="1"><?php esc_html_e('Sign Up', 'woocommerce'); ?></h1>
        <p>Create your account and start designing the home you love.</p>
    </div>

    <form class="Form-root Form-register woocommerce-form" method="post" novalidate>
        <?php do_action('woocommerce_register_form_start'); ?>

        <div class="FormControl-group">
            <div class="FormControl-root FormControl-required">
                <label for="reg_username"
                    class="FormControl-label"><?php esc_html_e('Username', 'woocommerce'); ?></label>
                <div class="InputBase-root">
                    <input type="text" class="InputBase-input" name="username" id="reg_username" autocomplete="username"
                        value="<?php echo (!empty($_POST['username'])) ? esc_attr(wp_unslash($_POST['username'])) : ''; ?>"
                        required aria-required="true">
                    <fieldset>
                        <legend>Username *</legend>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="FormControl-group">
            <div class="FormControl-root FormControl-required">
                <label for="reg_email"
                    class="FormControl-label"><?php esc_html_e('Email address', 'woocommerce'); ?></label>
                <div class="InputBase-root">
                    <input type="email" class="InputBase-input" name="email" id="reg_email" autocomplete="email"
                        value="<?php echo (!empty($_POST['email'])) ? esc_attr(wp_unslash($_POST['email'])) : ''; ?>"
                        required aria-required="true">
                    <fieldset>
                        <legend>Email address *</legend>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="FormControl-group">
            <div class="FormControl-root FormControl-required">
                <label for="reg_password"
                    class="FormControl-label"><?php esc_html_e('Password', 'woocommerce'); ?></label>
                <div class="InputBase-root">
                    <input type="password" class="InputBase-input" name="password" id="reg_password"
                        autocomplete="new-password" required aria-required="true">
                    <fieldset>
                        <legend>Password *</legend>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="Form-row">
            <div class="FormControl-group">
                <label class="Form-checkbox">
                    <input type="checkbox" name="agree_terms" value="1" required>
                    <span>
                        I agree to the
                        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('terms'))); ?>" target="_blank">
                            Terms & Conditions
                        </a>
                        and
                        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" target="_blank">
                            Privacy Policy
                        </a>
                    </span>
                </label>
            </div>
        </div>

        <?php // do_action('woocommerce_register_form'); ?>

        <div class="Form-action">
            <?php wp_nonce_field('woocommerce-register', 'woocommerce-register-nonce'); ?>
            <button type="submit" class="Button-root Button-primary Button-icon-start woocommerce-form-register__submit"
                name="register" data-variant="contained" value="<?php esc_attr_e('Register', 'woocommerce'); ?>">
                <iconify-icon icon="line-md:login"></iconify-icon>
                <?php esc_html_e('Register', 'woocommerce'); ?>
            </button>
        </div>

        <?php do_action('woocommerce_register_form_end'); ?>

        <div class="sign-up-bar">or</div>
        <div class="sign-up">
            Already have an account?
            <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>?action=login">Login</a>
        </div>
    </form>
</div>