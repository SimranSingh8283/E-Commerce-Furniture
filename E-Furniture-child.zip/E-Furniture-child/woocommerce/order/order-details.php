<?php
/**
 * Order details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 10.1.0
 *
 * @var bool $show_downloads Controls whether the downloads table should be rendered.
 */

// phpcs:disable WooCommerce.Commenting.CommentHooks.MissingHookComment

defined('ABSPATH') || exit;

$order = wc_get_order($order_id); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

if (!$order) {
    return;
}

$order_items = $order->get_items(apply_filters('woocommerce_purchase_order_item_types', 'line_item'));
$show_purchase_note = $order->has_status(apply_filters('woocommerce_purchase_note_order_statuses', array('completed', 'processing')));
$downloads = $order->get_downloadable_items();
$actions = array_filter(
    wc_get_account_orders_actions($order),
    function ($key) {
        return 'view' !== $key;
    },
    ARRAY_FILTER_USE_KEY
);

// We make sure the order belongs to the user. This will also be true if the user is a guest, and the order belongs to a guest (userID === 0).
$show_customer_details = $order->get_user_id() === get_current_user_id();

if ($show_downloads) {
    wc_get_template(
        'order/order-downloads.php',
        array(
            'downloads' => $downloads,
            'show_title' => true,
        )
    );
}
?>
<div class="Product-details">
    <div class="Block-heading">
        <span aria-level="1" data-level="1"><?php esc_html_e('Products', 'woocommerce'); ?></span>
    </div>

    <div class="Product-list">
        <?php
        foreach ($order_items as $item_id => $item) {
            $product = $item->get_product();

            wc_get_template(
                'order/order-details-item.php',
                array(
                    'order' => $order,
                    'item_id' => $item_id,
                    'item' => $item,
                    'show_purchase_note' => $show_purchase_note,
                    'purchase_note' => $product ? $product->get_purchase_note() : '',
                    'product' => $product,
                )
            );
        }
        ?>
    </div>

    <div class="Cart-summary">
        <div class="Block-heading">
            <span aria-level="1" data-level="1">Order Summary</span>
        </div>

        <ul class="Summary-root">
            <li class="Summary-item">
                <span><?php esc_html_e('Items', 'woocommerce'); ?></span>
                <span><?php echo esc_html($order->get_item_count()); ?></span>
            </li>

            <li class="Summary-item">
                <span><?php esc_html_e('Subtotal', 'woocommerce'); ?></span>
                <span><?php echo wc_price($order->get_subtotal()); ?></span>
            </li>

            <?php if ($order->get_shipping_total() > 0): ?>
                <li class="Summary-item shipping">
                    <span><?php esc_html_e('Shipping', 'woocommerce'); ?></span>
                    <span>
                        <?php
                        echo wc_price($order->get_shipping_total());
                        if ($order->get_shipping_method()) {
                            echo '<small> (' . esc_html($order->get_shipping_method()) . ')</small>';
                        }
                        ?>
                    </span>
                </li>
            <?php endif; ?>

            <?php if (wc_tax_enabled()): ?>
                <?php if ('itemized' === get_option('woocommerce_tax_total_display')): ?>
                    <?php foreach ($order->get_tax_totals() as $tax): ?>
                        <li class="Summary-item tax">
                            <span><?php echo esc_html($tax->label); ?></span>
                            <span><?php echo wp_kses_post($tax->formatted_amount); ?></span>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="Summary-item tax">
                        <span><?php esc_html_e('Taxes', 'woocommerce'); ?></span>
                        <span><?php echo wc_price($order->get_total_tax()); ?></span>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <li class="Summary-item payment">
                <span><?php esc_html_e('Payment method', 'woocommerce'); ?></span>
                <span><?php echo esc_html($order->get_payment_method_title()); ?></span>
            </li>

            <li class="Summary-item total">
                <span><?php esc_html_e('Total', 'woocommerce'); ?></span>
                <strong class="Summary-total">
                    <?php echo wc_price($order->get_total()); ?>
                </strong>
            </li>

        </ul>
    </div>
</div>