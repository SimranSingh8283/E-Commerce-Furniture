<?php
defined('ABSPATH') || exit;

get_header('shop');

get_template_part('template-parts/products/category-layout');

get_footer('shop');